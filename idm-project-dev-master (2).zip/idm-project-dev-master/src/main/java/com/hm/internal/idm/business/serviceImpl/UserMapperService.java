package com.hm.internal.idm.business.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hm.internal.idm.dataaccess.repository.UserRepository;

@Service
public class UserMapperService {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	private Set<Role> rolesSet = new LinkedHashSet<>();
	
	public User getUser(UserDto userDto) {
		 User user = new User();
		 Long id= new Long(userRepository.count()+1);
		 user.setName(userDto.getName());
		 user.setUserName(userDto.getUserName());
		 user.setEmailId(userDto.getEmailId());
		 user.setId(id);
		 List<String> roles = userDto.getRoles();
		 for(String role:roles) {
			 Optional<Role> role = roleRepository.findByDescription(role);
			 if(role.isPresent()) {
				 rolesSet.add(role.get()); 
			 }
		 }
		 user.setRolesSet(rolesSet);
		return user;
	}
	
	

}
