package com.hm.internal.idm.business.service;

public interface PermissionService {

	public Object getAllPermission();

	public Object getAllPermissionByFeature(String feature);
}
