package com.hm.internal.idm.idm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdmApplicationTests {

	@Test
	void contextLoads() {
	}

}
