package com.hm.internal.idm.web.model;

public class UserDto {
	
	private String userName;
	
	private String name;
	
	private String UserName;
	
	private String emailId;
	
	private List<String> roles;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public List<String> getRoles() {
		return rolesSet;
	}

	public void setRoles(List<String> rolesSet) {
		this.rolesSet = rolesSet;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	

}
